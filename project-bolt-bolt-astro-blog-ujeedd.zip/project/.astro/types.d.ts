/// <reference types="astro/client" />
/// <reference path="astro/content.d.ts" />